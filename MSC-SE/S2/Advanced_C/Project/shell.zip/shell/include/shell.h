#ifndef SHELL_H
#define SHELL_H

/* Tokenizer */
char **tokenize(const char *line, int *count);
void free_tokens(char **tokens, int count);

/* Command execution */
int execute_command(char **tokens, int count);
int execute_pipeline(char **tokens, int count);

/* Built-in commands */
int handle_builtin(char **tokens);

/* I/O redirection */
int apply_redirections(char **tokens, int count);

/* Run a command line */
int run_command_line(char **tokens, int count);

/* Globbing */
char **expand_glob(char **tokens, int count, int *new_count);

/* Terminal */
void ensure_newline(void);
char *read_line(void);

#endif
