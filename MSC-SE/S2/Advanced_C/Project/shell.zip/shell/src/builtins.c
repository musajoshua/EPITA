#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shell.h"

// @returns -1 "not a builtin" (so the caller knows to try external execution)
// @returns 0 "builtin ran successfully"
// @returns 1 "builtin ran but failed"
int handle_builtin(char **tokens)
{
    // Handle the cd builtin command
    if (strcmp(tokens[0], "cd") == 0)
    {
        if (tokens[1] == NULL)
        {
            char *home = getenv("HOME");
            if (home)
            {
                if (chdir(home) < 0)
                {
                    perror("jsh: cd");
                    return 1;
                }
                return 0;
            }
            fprintf(stderr, "jsh: cd: HOME not set\n");
        }
        else
        {
            if (chdir(tokens[1]) < 0)
            {
                perror("jsh: cd");
                return 1;
            }
            return 0;
        }
        return 1;
    }

    // Handle the exit builtin command
    if (strcmp(tokens[0], "exit") == 0)
        exit(0);

    // Handle the pwd builtin command
    if (strcmp(tokens[0], "pwd") == 0)
    {
        char cwd[1024];
        if (getcwd(cwd, sizeof(cwd)))
        {
            printf("%s\n", cwd);
            return 0;
        }
        perror("jsh: pwd");
        return 1;
    }

    // Not a builtin command
    return -1;
}
