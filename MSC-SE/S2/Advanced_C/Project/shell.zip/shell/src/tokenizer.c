#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "shell.h"

/* Split a line into a NULL-terminated array of word tokens. */
char **tokenize(const char *line, int *count)
{
    int capacity = 8;
    int n = 0;
    char **tokens = malloc(capacity * sizeof(char *));

    if (!tokens)
        return NULL;

    int i = 0;
    int len = strlen(line);

    while (i < len)
    {
        while (isspace((unsigned char)line[i]))
            i++;

        if (i >= len)
            break;

        int start = i;

        while (i < len && !isspace((unsigned char)line[i]))
            i++;

        int word_len = i - start;

        char *token = malloc(word_len + 1);
        if (!token)
        {
            free_tokens(tokens, n);
            return NULL;
        }

        memcpy(token, &line[start], word_len);
        token[word_len] = '\0';

        if (n >= capacity)
        {
            capacity *= 2;
            char **tmp = realloc(tokens, capacity * sizeof(char *));
            if (!tmp)
            {
                free(token);
                free_tokens(tokens, n);
                return NULL;
            }
            tokens = tmp;
        }
        tokens[n] = token;
        n++;
    }

    if (n == 0)
    {
        free(tokens);
        *count = 0;
        return NULL;
    }

    /* Shrink to exact size + 1 for NULL terminator */
    char **temp = realloc(tokens, (n + 1) * sizeof(char *));
    if (!temp)
    {
        free_tokens(tokens, n);
        return NULL;
    }
    tokens = temp;
    tokens[n] = NULL;
    *count = n;
    return tokens;
}

void free_tokens(char **tokens, int count)
{
    if (!tokens) return;

    for (int i = 0; i < count; i++)
        free(tokens[i]);
    free(tokens);
}
