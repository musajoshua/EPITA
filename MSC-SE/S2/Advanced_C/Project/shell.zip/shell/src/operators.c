#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "shell.h"

/*
 * Split a token array on ;, &&, || and dispatch each segment.
 * Returns the exit code of the last command that ran.
 */
int run_command_line(char **tokens, int count)
{
    int last_exit = 0;

    // Split tokens into segments at each operator
    // For each segment: find its start and length
    // Then dispatch it (pipe check -> builtin check -> execute)

    // 0 = none (first segment) or ;
    // 1 = &&
    // 2 = ||
    int previous_operator = 0;
    int seg_start = 0;

    for (int i = 0; i <= count; i++)
    {
        // -1 = not an operator (just a regular token)
        // 0 = ; (always run)
        // 1 = &&
        // 2 = ||
        int current_operator = -1;
        if (i < count)
        {
            if (strcmp(tokens[i], "&&") == 0)
                current_operator = 1;
            else if (strcmp(tokens[i], "||") == 0)
                current_operator = 2;
            else if (strcmp(tokens[i], ";") == 0)
                current_operator = 0;
        }

        // End of a segment: either we hit an operator or reached the end
        if (i == count || current_operator != -1)
        {
            int seg_len = i - seg_start;

            if (seg_len > 0)
            {
                // Build a pointer to this segment's tokens
                char **seg_tokens = &tokens[seg_start];

                // Null-terminate this segment (if we hit an operator)
                if (i < count)
                    tokens[i] = NULL;

                char **expanded = expand_glob(seg_tokens, seg_len, &seg_len);
                if (!expanded)
                    continue;

                // Check for pipes
                bool has_pipe = false;
                for (int j = 0; j < seg_len; j++)
                {
                    if (strcmp(expanded[j], "|") == 0)
                    {
                        has_pipe = true;
                        break;
                    }
                }

                // Decide whether to run based on previous operator
                bool should_run = true;
                if (previous_operator == 1 && last_exit != 0)
                    should_run = false;
                if (previous_operator == 2 && last_exit == 0)
                    should_run = false;

                if (should_run)
                {
                    if (has_pipe)
                    {
                        last_exit = execute_pipeline(expanded, seg_len);
                    }
                    else
                    {
                        int builtin_result = handle_builtin(expanded);
                        if (builtin_result != -1)
                            last_exit = builtin_result;
                        else
                            last_exit = execute_command(expanded, seg_len);
                    }
                }
                free_tokens(expanded, seg_len);
            }

            seg_start = i + 1;
            previous_operator = current_operator;
        }
    }

    return last_exit;
}
