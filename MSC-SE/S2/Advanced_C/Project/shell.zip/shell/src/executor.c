#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include "shell.h"

/* Fork a child, apply redirections, exec the command, return exit code. */
int execute_command(char **tokens, int count)
{
    pid_t pid = fork();

    if (pid < 0)
    {
        perror("jsh:fork");
        return -1;
    }
    else if (pid == 0)
    {
        signal(SIGINT, SIG_DFL);

        if (apply_redirections(tokens, count) < 0)
            exit(1);

        execvp(tokens[0], tokens);
        perror("jsh:execvp");
        exit(1);
    }
    else
    {
        int status;
        waitpid(pid, &status, 0);
        if (WIFEXITED(status))
            return WEXITSTATUS(status);
        return 1;
    }
}
