#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include "shell.h"

int main(void)
{
    // Parent shell ignores Ctrl+C so it doesn't die
    signal(SIGINT, SIG_IGN);

    while (1)
    {
        ensure_newline();
        printf("jsh $ ");
        fflush(stdout);

        char *line = read_line();

        if (line == NULL)
            break;

        // Skip empty input
        if (line[0] == '\0')
        {
            free(line);
            continue;
        }

        int count = 0;
        char **tokens = tokenize(line, &count);
        free(line);

        if (!tokens)
            continue;

        run_command_line(tokens, count);
        free_tokens(tokens, count);
    }

    printf("\n");
    return 0;
}
