#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include "shell.h"

/* Execute a pipeline (e.g., ls | grep .c | wc -l). Returns last command's exit code. */
int execute_pipeline(char **tokens, int count)
{
    pid_t last_pid;
    int last_status = 1;
    int num_pipe_cmds = 0;
    char **commands[count];

    /* Split tokens into commands at each "|" */
    commands[num_pipe_cmds] = &tokens[0];
    num_pipe_cmds += 1;

    for (int i = 0; i < count; i++)
    {
        if (strcmp(tokens[i], "|") == 0)
        {
            tokens[i] = NULL;
            commands[num_pipe_cmds] = &tokens[i + 1];
            num_pipe_cmds += 1;
        }
    }

    int prev_fd = -1;

    for (int i = 0; i < num_pipe_cmds; i++)
    {
        int pipe_fd[2];
        if (i != num_pipe_cmds - 1)
        {
            if (pipe(pipe_fd) == -1)
            {
                perror("jsh:pipe");
                return -1;
            }
        }

        pid_t pid = fork();

        if (pid < 0)
        {
            perror("jsh:fork");
            return -1;
        }
        else if (pid == 0)
        {
            signal(SIGINT, SIG_DFL);

            // Read from previous pipe (if not first command)
            if (i > 0)
            {
                dup2(prev_fd, STDIN_FILENO);
                close(prev_fd);
            }

            // Write to current pipe (if not last command)
            if (i != num_pipe_cmds - 1)
            {
                dup2(pipe_fd[1], STDOUT_FILENO);
                close(pipe_fd[0]);
                close(pipe_fd[1]);
            }

            // Count tokens in this pipeline segment
            int cmd_count = 0;
            while (commands[i][cmd_count] != NULL)
                cmd_count++;

            if (apply_redirections(commands[i], cmd_count) < 0)
                exit(1);

            execvp(commands[i][0], commands[i]);
            perror("jsh:execvp");
            exit(1);
        }
        else
        {
            last_pid = pid;
            if (prev_fd != -1)
                close(prev_fd);

            if (i != num_pipe_cmds - 1)
            {
                close(pipe_fd[1]);
                prev_fd = pipe_fd[0];
            }
        }
    }

    /* Wait for all children; capture last command's exit code */
    int status;
    for (int i = 0; i < num_pipe_cmds; i++)
    {
        pid_t waited = waitpid(-1, &status, 0);
        if (waited == last_pid)
        {
            if (WIFEXITED(status))
                last_status = WEXITSTATUS(status);
            else
                last_status = 1;
        }
    }

    return last_status;
}
