#include <stdlib.h>
#include <string.h>
#include <glob.h>
#include "shell.h"

/*
 * Expand wildcard tokens (* and ?) into matching filenames.
 * Non-wildcard tokens are copied as-is.
 * Returns a new NULL-terminated token array; caller must free it.
 */
char **expand_glob(char **tokens, int count, int *new_count)
{
    int match_count = 0;
    int capacity = count;
    char **result = malloc(capacity * sizeof(char *));
    if (!result)
        return NULL;

    for (int i = 0; i < count; i++)
    {
        if (strchr(tokens[i], '*') == NULL && strchr(tokens[i], '?') == NULL)
        {
            if (match_count >= capacity)
            {
                capacity *= 2;
                char **tmp = realloc(result, capacity * sizeof(char *));
                if (!tmp)
                {
                    free_tokens(result, match_count);
                    return NULL;
                }
                result = tmp;
            }
            result[match_count] = strdup(tokens[i]);
            match_count++;
        }
        else
        {
            glob_t glob_result;
            if (glob(tokens[i], 0, NULL, &glob_result) == 0)
            {
                for (size_t j = 0; j < glob_result.gl_pathc; j++)
                {
                    if (match_count >= capacity)
                    {
                        capacity *= 2;
                        char **tmp = realloc(result, capacity * sizeof(char *));
                        if (!tmp)
                        {
                            globfree(&glob_result);
                            free_tokens(result, match_count);
                            return NULL;
                        }
                        result = tmp;
                    }
                    result[match_count] = strdup(glob_result.gl_pathv[j]);
                    match_count++;
                }
                globfree(&glob_result);
            }
            else
            {
                /* No matches -- keep original token */
                if (match_count >= capacity)
                {
                    capacity *= 2;
                    char **tmp = realloc(result, capacity * sizeof(char *));
                    if (!tmp)
                    {
                        free_tokens(result, match_count);
                        return NULL;
                    }
                    result = tmp;
                }
                result[match_count] = strdup(tokens[i]);
                match_count++;
            }
        }
    }

    /* Ensure room for NULL terminator */
    if (match_count >= capacity)
    {
        capacity += 1;
        char **tmp = realloc(result, capacity * sizeof(char *));
        if (!tmp)
        {
            free_tokens(result, match_count);
            return NULL;
        }
        result = tmp;
    }
    result[match_count] = NULL;
    *new_count = match_count;
    return result;
}
