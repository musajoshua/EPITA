#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

#define MAX_HISTORY_SIZE 100

static char *history[MAX_HISTORY_SIZE];
static int history_count = 0;

/*
 * Query the terminal for the cursor column. If the cursor is not
 * at column 1 (i.e., the previous command left output without a
 * trailing newline), print a newline so the prompt starts fresh.
 */
void ensure_newline(void)
{
    struct termios old, raw;

    tcgetattr(STDIN_FILENO, &old);
    raw = old;
    raw.c_lflag &= ~(ECHO | ICANON);
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 1;
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);

    /* Send "Device Status Report" escape to get cursor position */
    write(STDOUT_FILENO, "\033[6n", 4);

    char buffer[32];
    int i = 0;
    char c;
    while (i < 31 && read(STDIN_FILENO, &c, 1) == 1 && c != 'R')
        buffer[i++] = c;
    buffer[i] = '\0';

    /* Response format: \033[row;colR -- extract col after ';' */
    char *semicolon = strchr(buffer, ';');
    if (semicolon)
    {
        int col = atoi(semicolon + 1);
        if (col > 1)
            write(STDOUT_FILENO, "\n", 1);
    }

    tcsetattr(STDIN_FILENO, TCSANOW, &old);
}

/* Append a non-empty line to the history ring buffer. */
void add_to_history(const char *line)
{
    if (strcmp(line, "") == 0)
        return;

    if (history_count >= MAX_HISTORY_SIZE)
    {
        free(history[0]);
        memmove(history, history + 1, (MAX_HISTORY_SIZE - 1) * sizeof(char *));
        history_count -= 1;
    }

    history[history_count] = strdup(line);
    history_count++;
}

/*
 * Read a line from stdin in raw mode with:
 *   - character-by-character echo
 *   - backspace handling
 *   - up/down arrow for history navigation
 *   - left/right arrow for cursor movement
 *   - Ctrl+D for EOF
 * Returns a malloc'd string, or NULL on EOF / alloc failure.
 */
char *read_line(void)
{
    int len = 0;
    int pos = 0;
    int capacity = 256;

    char *buffer = malloc(capacity);
    if (!buffer)
        return NULL;
    buffer[0] = '\0';

    int history_index = history_count;

    struct termios old, raw;
    tcgetattr(STDIN_FILENO, &old);
    raw = old;
    raw.c_lflag &= ~(ECHO | ICANON);
    raw.c_cc[VMIN] = 1;
    raw.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);

    while (1)
    {
        char c;
        read(STDIN_FILENO, &c, 1);

        if (c >= 32 && c <= 126)
        {
            if (len + 1 >= capacity)
            {
                capacity *= 2;
                char *tmp = realloc(buffer, capacity);
                if (!tmp)
                {
                    free(buffer);
                    tcsetattr(STDIN_FILENO, TCSANOW, &old);
                    return NULL;
                }
                buffer = tmp;
            }

            if (pos == len)
            {
                buffer[len] = c;
                len += 1;
                pos += 1;
                write(STDOUT_FILENO, &c, 1);
            }
        }
        else if (c == '\n')
        {
            buffer[len] = '\0';
            write(STDOUT_FILENO, "\n", 1);
            add_to_history(buffer);
            break;
        }
        else if (c == 127 || c == '\b')
        {
            if (pos > 0)
            {
                write(STDOUT_FILENO, "\b \b", 3);
                pos -= 1;
                len -= 1;
            }
        }
        else if (c == '\033')
        {
            char seq[2];
            if (read(STDIN_FILENO, &seq[0], 1) != 1) continue;
            if (read(STDIN_FILENO, &seq[1], 1) != 1) continue;
            if (seq[0] != '[') continue;

            // Up arrow key
            if (seq[1] == 'A')
            {
                if (history_index > 0)
                {
                    history_index -= 1;

                    int entry_len = strlen(history[history_index]);
                    if (entry_len + 1 >= capacity)
                    {
                        capacity = entry_len + 2;
                        char *tmp = realloc(buffer, capacity);
                        if (!tmp) continue;
                        buffer = tmp;
                    }

                    strcpy(buffer, history[history_index]);
                    len = entry_len;
                    pos = len;
                    // Clear current line and reprint
                    write(STDOUT_FILENO, "\r", 1);       // cursor to column 0
                    write(STDOUT_FILENO, "\033[K", 3);   // erase from cursor to end
                    write(STDOUT_FILENO, "jsh $ ", 6);   // reprint prompt
                    // Print the new content
                    write(STDOUT_FILENO, buffer, len);
                }
            }
            // Down arrow key
            else if (seq[1] == 'B')
            {
                if (history_index < history_count - 1)
                {
                    history_index += 1;

                    int entry_len = strlen(history[history_index]);
                    if (entry_len + 1 >= capacity)
                    {
                        capacity = entry_len + 2;
                        char *tmp = realloc(buffer, capacity);
                        if (!tmp) continue;
                        buffer = tmp;
                    }

                    strcpy(buffer, history[history_index]);
                    len = entry_len;
                    pos = len;
                    // Clear current line and reprint
                    write(STDOUT_FILENO, "\r", 1);       // cursor to column 0
                    write(STDOUT_FILENO, "\033[K", 3);   // erase from cursor to end
                    write(STDOUT_FILENO, "jsh $ ", 6);   // reprint prompt
                    // Print the new content
                    write(STDOUT_FILENO, buffer, len);
                }
                else if (history_index == history_count - 1)
                {
                    history_index = history_count;
                    buffer[0] = '\0';
                    len = 0;
                    pos = 0;
                    // Clear current line and reprint
                    write(STDOUT_FILENO, "\r", 1);       // cursor to column 0
                    write(STDOUT_FILENO, "\033[K", 3);   // erase from cursor to end
                    write(STDOUT_FILENO, "jsh $ ", 6);   // reprint prompt
                    // Print the new content
                    write(STDOUT_FILENO, buffer, len);
                }
            }
            // Right arrow key
            else if (seq[1] == 'C')
            {
                if (pos < len)
                {
                    pos += 1;
                    write(STDOUT_FILENO, "\033[C", 3);
                }
            }
            // Left arrow key
            else if (seq[1] == 'D')
            {
                if (pos > 0)
                {
                    pos -= 1;
                    write(STDOUT_FILENO, "\033[D", 3);
                }
            }
        }
        // Ctrl+D
        else if (c == 4)
        {
            free(buffer);
            tcsetattr(STDIN_FILENO, TCSANOW, &old);
            return NULL;
        }
    }

    tcsetattr(STDIN_FILENO, TCSANOW, &old);
    return buffer;
}
