#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include "shell.h"

/*
 * Scan tokens for >, >>, <. For each one: open the file,
 * dup2 to redirect the fd, then remove the operator and
 * filename from the token array by shifting left.
 */
int apply_redirections(char **tokens, int count)
{
    for (int i = 0; i < count; i++)
    {
        if (strcmp(tokens[i], ">>") == 0)
        {
            if (tokens[i + 1] == NULL)
            {
                fprintf(stderr, "jsh: missing filename after >>\n");
                return -1;
            }

            // create the file if it doesn't exist or append to it if it does
            int fd = open(tokens[i + 1], O_CREAT | O_WRONLY | O_APPEND, 0644);
            if (fd == -1)
            {
                perror("jsh: could not write to file");
                return -1;
            }

            dup2(fd, STDOUT_FILENO);
            close(fd);

            /* Remove operator and filename from tokens */
            int j = i;
            while (j + 2 < count)
            {
                tokens[j] = tokens[j + 2];
                j++;
            }
            count -= 2;
            tokens[count] = NULL;
            i--;
        }
        else if (strcmp(tokens[i], ">") == 0)
        {
            if (tokens[i + 1] == NULL)
            {
                fprintf(stderr, "jsh: missing filename after >\n");
                return -1;
            }

            // create the file if it doesn't exist or overwrite it if it does
            int fd = open(tokens[i + 1], O_CREAT | O_WRONLY | O_TRUNC, 0644);
            if (fd == -1)
            {
                perror("jsh: could not write to file");
                return -1;
            }

            dup2(fd, STDOUT_FILENO);
            close(fd);

            int j = i;
            while (j + 2 < count)
            {
                tokens[j] = tokens[j + 2];
                j++;
            }
            count -= 2;
            tokens[count] = NULL;
            i--;
        }
        else if (strcmp(tokens[i], "<") == 0)
        {
            if (tokens[i + 1] == NULL)
            {
                fprintf(stderr, "jsh: missing filename after <\n");
                return -1;
            }

            // open the file in read only mode
            int fd = open(tokens[i + 1], O_RDONLY);
            if (fd == -1)
            {
                perror("jsh: could not read from file");
                return -1;
            }

            dup2(fd, STDIN_FILENO);
            close(fd);

            int j = i;
            while (j + 2 < count)
            {
                tokens[j] = tokens[j + 2];
                j++;
            }
            count -= 2;
            tokens[count] = NULL;
            i--;
        }
    }
    return 0;
}
