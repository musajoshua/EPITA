#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "lexer.h"

/*
 * C CONCEPTS USED IN THIS FILE:
 *
 * 1. Dynamic arrays with realloc:
 *    We don't know how many tokens the user will type, so we start
 *    with a small array (capacity=8) and double it whenever it fills up.
 *    This is the standard "growing array" pattern in C.
 *
 * 2. strdup-like extraction:
 *    extract_token() does malloc + memcpy to copy each token into its
 *    own memory. Each token owns its own memory and can be freed
 *    independently.
 *
 * 3. NULL-terminated arrays:
 *    We add NULL at the end of the tokens array. This is required
 *    by execvp() -- it reads argv until it hits NULL.
 *
 * 4. ctype.h (isspace):
 *    isspace(c) returns true for ' ', '\t', '\n', '\r', etc.
 *    Safer than checking for ' ' alone.
 */

static char *extract_token(const char *start, int length)
{
    char *token = malloc(length + 1);
    if (!token)
        return NULL;
    memcpy(token, start, length);
    token[length] = '\0';
    return token;
}

char **tokenize(const char *line, int *count)
{
    int capacity = 8;
    int n = 0;
    char **tokens = malloc(capacity * sizeof(char *));
    if (!tokens)
        return NULL;

    int i = 0;
    int len = strlen(line);

    while (i < len) {
        while (i < len && isspace((unsigned char)line[i]))
            i++;

        if (i >= len)
            break;

        int start = i;

        while (i < len && !isspace((unsigned char)line[i]))
            i++;

        if (n >= capacity) {
            capacity *= 2;
            char **tmp = realloc(tokens, capacity * sizeof(char *));
            if (!tmp) {
                free_tokens(tokens, n);
                return NULL;
            }
            tokens = tmp;
        }

        tokens[n] = extract_token(&line[start], i - start);
        if (!tokens[n]) {
            free_tokens(tokens, n);
            return NULL;
        }
        n++;
    }

    if (n == 0) {
        free(tokens);
        *count = 0;
        return NULL;
    }

    char **tmp = realloc(tokens, (n + 1) * sizeof(char *));
    if (!tmp) {
        free_tokens(tokens, n);
        return NULL;
    }
    tokens = tmp;
    tokens[n] = NULL;

    *count = n;
    return tokens;
}

void free_tokens(char **tokens, int count)
{
    if (!tokens)
        return;
    for (int i = 0; i < count; i++)
        free(tokens[i]);
    free(tokens);
}
