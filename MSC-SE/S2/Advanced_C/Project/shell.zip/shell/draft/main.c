#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lexer.h"
#include "utils.h"

int main(void)
{
    char *line = NULL;
    size_t len = 0;
    ssize_t nread;

    while (1) {
        printf("jsh $ ");

        nread = getline(&line, &len, stdin);
        if (nread == -1)
            break;

        line[strcspn(line, "\n")] = '\0';

        if (line[0] == '\0')
            continue;

        int count = 0;
        char **tokens = tokenize(line, &count);
        if (!tokens)
            continue;

        printf("[DEBUG] %d token(s):\n", count);
        for (int i = 0; i < count; i++)
            printf("  [%d] \"%s\"\n", i, tokens[i]);

        free_tokens(tokens, count);
    }

    printf("\n");
    free(line);
    return 0;
}
