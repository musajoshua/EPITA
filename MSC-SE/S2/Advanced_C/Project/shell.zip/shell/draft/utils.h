#ifndef UTILS_H
#define UTILS_H

/*
 * Utility functions for the shell.
 * Will grow as we add features.
 */

#endif
