#ifndef LEXER_H
#define LEXER_H

/*
 * tokenize - splits an input line into an array of token strings.
 *
 * Splits on whitespace (spaces and tabs). The returned array is
 * NULL-terminated (tokens[count] == NULL) so it can be passed
 * directly to execvp() later.
 *
 * @line:   the input string to tokenize
 * @count:  output parameter -- set to the number of tokens found
 *
 * Returns: a malloc'd array of malloc'd strings, or NULL on empty input.
 *          Caller must free with free_tokens().
 */
char **tokenize(const char *line, int *count);

/*
 * free_tokens - frees the array returned by tokenize().
 */
void free_tokens(char **tokens, int count);

#endif
