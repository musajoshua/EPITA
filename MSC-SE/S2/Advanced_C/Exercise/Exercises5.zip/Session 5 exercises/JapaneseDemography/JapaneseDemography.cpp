// JapaneseDemography.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Japan: Hiroshi Yoshida, d�mograph, claims that if japanese birth rate declines at today's 
// pace, the last japanese baby will be born in 2720..
// Let's write a code that checks Mr Yoshida's statement
// input data: japanese births in 2024: 687000 - decrease % 2023: 2.3%

#include <iostream>
#include <cmath>
int main()
{
    double BirthsPerYear = 687000;
    int year = 2024;
    while(BirthsPerYear > 1 )
    {
        BirthsPerYear *= (1 - (2.3 / 100));

        year++;// increment year
        std::cout << "\n Births in " << year << " : " << BirthsPerYear;
    }
    std::cout << "\n Japan will have its last baby by : " << year;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
