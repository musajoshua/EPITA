// MutexThread.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <unordered_map>
#include <string>
#include <queue>
#include <vector>
#include <thread>
#include <mutex>
#include <condition_variable>

using namespace std;

class Subscriber; // Forward declaration

class Message {
    string message;
public:
    Message(string message) : message(message) {}
    string getMessage() const { return message; }
};

class Broker {
    unordered_map<string, queue<Message*>> topics;
    unordered_map<string, vector<Subscriber*>> subscribers;
    mutex mutex_;
    condition_variable cond_;
public:
    void subscribe(const string& topic, Subscriber* sub);
    void publish(const string& topic, Message* message);
    void processMessages();
};

class Publisher {
    Broker* broker;
public:
    Publisher(Broker& broker) : broker(&broker) {}
    void publish(const string& topic, Message* message) {
        broker->publish(topic, message);
    }
};

class Subscriber {
    Broker* broker;
public:
    Subscriber(Broker& broker) : broker(&broker) {}
    void subscribe(const string& topic) {
        broker->subscribe(topic, this);
    }
    void receive(const Message* message, const string& topic) {
        cout << "Received message: " << message->getMessage() << ", from topic: " << topic << endl;
    }
};

void Broker::subscribe(const string& topic, Subscriber* sub) {
    lock_guard<mutex> lock(mutex_);
    subscribers[topic].push_back(sub);
}

void Broker::publish(const string& topic, Message* message) {
    {
        lock_guard<mutex> lock(mutex_);
        topics[topic].push(message);
    }
    cond_.notify_all();
}

void Broker::processMessages() {
    unique_lock<mutex> lock(mutex_);
    while (true) {
        cond_.wait(lock, [this] {
            for (const auto& topic : topics) {
                if (!topic.second.empty()) {
                    return true;
                }
            }
            return false;
            });
        for (auto& topic : topics) {
            string topic_name = topic.first;
            queue<Message*>& q = topic.second;
            while (!q.empty()) {
                Message* m = q.front();
                q.pop();
                vector<Subscriber*>& subs = subscribers[topic_name];
                for (auto& sub : subs) {
                    sub->receive(m, topic_name);
                }
            }
        }
    }
}

int main() {
    Broker broker;

    Publisher pub(broker);
    Subscriber sub1(broker), sub2(broker);

    sub1.subscribe("A");
    sub2.subscribe("B");

    thread t(&Broker::processMessages, &broker);

    pub.publish("A", new Message("Hello, Topic A!"));
    pub.publish("B", new Message("Hello, Topic B!"));

    t.join();
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
