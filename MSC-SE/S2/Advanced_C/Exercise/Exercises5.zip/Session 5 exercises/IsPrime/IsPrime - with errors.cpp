// IsPrime.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// IsPrime.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <chrono>
using namespace std;

// function to check if a given integer is prime
int is_Prime(int n)
{
    if (n <= 1) {
        return 0;
    }
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return 0;
        }
    }
    return 1;
}
int main()
{
    chrono::steady_clock::time_point begin = chrono::steady_clock::now();

    int n;

    cin >> n;
    cout << "\n this program calculates and display the prime numbers just below and just above " << n << std::endl;

    int i = 1;
    int lastprime = 1;
    int primeBelowN;
    int primeAboveN;

    while (i < 2*n)
    {
        if (is_Prime(i) == 1)
        {
            cout << "\n prime number found : " << i << std::endl;
            if (i > n)
            {
                primeBelowN = lastprime;
                primeAboveN = i;

            }
        }
        i++;
    }
    cout << "\n the nth prime integer below" << n << "is : " << primeBelowN << std::endl;
    cout << "\n the nth prime integer above" << n << "is : " << primeAboveN << std::endl;

    chrono::steady_clock::time_point end = chrono::steady_clock::now();
    cout << "Elapsed Time (sec) = " << (chrono::duration_cast<chrono::microseconds>(end - begin).count()) / 1000000.0 << std::endl;

}




// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
