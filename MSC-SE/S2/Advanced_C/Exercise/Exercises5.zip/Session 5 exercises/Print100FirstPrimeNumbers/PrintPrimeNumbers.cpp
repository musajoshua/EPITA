// Print100FirstPrimeNumbers.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#define N 1000
using namespace std;

int main()
{
    int n, p;
    bool notprime = true;
    std::cout << "List prime numbers : " << std::endl;

    for (n = 1; n < N; n++) 
    {
        notprime = false;
        for (p = 2; p < n; p++) 
        // NOTE : Dinh rightly said that we can loop p from 2 to sqrt(n), no need to loop from 2 to n : correct!
        {
            if (n % p == 0)
                notprime = true;
        }
        if (notprime == false)
        {
            std::cout << "\n " << n << " is a prime number";
        }
    }
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
