
#include<iostream>
using namespace std;

double maximum(double arr[], int len) {
	double max = -100;
	for (int i = 0; i < len; i++) {
		if (max < arr[i])
			max = arr[i];
	}
	return max;
}

double minimun(double arr1[], int len1) {
	double min = 100;
	for (int u = 0; u < len1; u++) {
		if (min > arr1[u])
			min = arr1[u];
	}
	return min;
}

int main() {
	int length;
	cout << "How many temperatures would you like to add (MAX 100) ?\n";
	cin >> length;
	double array[100];
	cout << "\n\n Enter the temperatures:\n";
	for (int p = 0; p < length; p++) 
	{
		cin >> array[p];
	}
	double maxT, minT;
	maxT = maximum(array, length);
	minT = minimun(array, length);

	cout << "\n\n The max. temperature of the day is: " << maxT;
	cout << "\n The min. temperature of the day is :" << minT;

	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
