// division.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream> // Include necessary header for input/output stream
#include "circle.h" 
#include "rectangle.h" 
#include "square.h" 
#include "triangle.h" 
#include "parallelogram.h" 

int main() {
    // Create instances of different shapes: Circle, Rectangle, and Triangle
    Circle circle(7.0); // Create a Circle object with radius 7.0
    Rectangle rectangle(4.2, 8.0); // Create a Rectangle object with length 4.2 and width 8.0
    Triangle triangle(4.0, 4.0, 3.2); // Create a Triangle object with sides 4.0, 4.0, and 3.2

    Parallelogram parallelogram(4.0, 5.0, 8.0); // Create a parallelogram object

    // Calculate and display the area and perimeter of each shape
    std::cout << "Circle: " << std::endl;
    std::cout << "Area: " << circle.calculateArea() << std::endl; // Calculate and output the area of the circle
    std::cout << "Perimeter: " << circle.calculatePerimeter() << std::endl; // Calculate and output the perimeter of the circle

    std::cout << "\nRectangle: " << std::endl;
    std::cout << "Area: " << rectangle.calculateArea() << std::endl; // Calculate and output the area of the rectangle
    std::cout << "Perimeter: " << rectangle.calculatePerimeter() << std::endl; // Calculate and output the perimeter of the rectangle

    std::cout << "\nTriangle: " << std::endl;
    std::cout << "Area: " << triangle.calculateArea() << std::endl; // Calculate and output the area of the triangle
    std::cout << "Perimeter: " << triangle.calculatePerimeter() << std::endl; // Calculate and output the perimeter of the triangle

    return 0; // Return 0 to indicate successful completion
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
