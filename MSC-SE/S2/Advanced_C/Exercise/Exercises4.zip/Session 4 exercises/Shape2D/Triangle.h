#pragma once
#include "Shape2D.h"
class Triangle : public Shape2D { // Define a derived class named Triangle inheriting from Shape
private:
    double side1; // Private member variable to store the first side of the triangle
    double side2; // Private member variable to store the second side of the triangle
    double side3; // Private member variable to store the third side of the triangle

public:
    // Constructor for Triangle class
    Triangle(double s1, double s2, double s3) : side1(s1), side2(s2), side3(s3) {}

    // Override the virtual member function to calculate the area
    double calculateArea() const override {
        // Use Heron's formula to calculate the area of a triangle
        double s = (side1 + side2 + side3) / 2; // semi-perimeter of the triangle
        return sqrt(s * (s - side1) * (s - side2) * (s - side3)); // area - Heron's formula
    }

    // Override the virtual member function to calculate the perimeter
    double calculatePerimeter() const override {
        return side1 + side2 + side3; // Calculate the perimeter of the triangle using its sides
    }
};
