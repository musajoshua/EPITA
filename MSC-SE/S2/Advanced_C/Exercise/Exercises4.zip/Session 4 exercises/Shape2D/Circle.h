#pragma once
#include "Shape2D.h"
class Circle : public Shape2D { // Define a derived class named Circle inheriting from Shape
private:
    double radius; // Private member variable to store the radius of the circle

public:
    // Constructor for Circle class
    Circle(double rad) : radius(rad) {}

    // Override the virtual member function to calculate the area
    double calculateArea() const override {
        return PI * pow(radius, 2); // Calculate the area of the circle using the radius
    }

    // Override the virtual member function to calculate the perimeter
    double calculatePerimeter() const override {
        return 2 * PI * radius; // Calculate the perimeter of the circle using the radius
    }
};