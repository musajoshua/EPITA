#pragma once
#include <cmath> // Include necessary header for mathematical functions

const double PI = 3.14159265358979323846; // Define constant value for PI

class Shape2D { // Define a base class named Shape2D
public:
    // Virtual member function to calculate the area (pure virtual function)
    virtual double calculateArea() const = 0;

    // Virtual member function to calculate the perimeter (pure virtual function)
    virtual double calculatePerimeter() const = 0;
};