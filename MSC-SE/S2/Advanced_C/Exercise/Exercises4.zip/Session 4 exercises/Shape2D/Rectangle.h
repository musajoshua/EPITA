#pragma once
#include "Shape2D.h"
class Rectangle : public Shape2D { // Derived class named Rectangle inheriting from Shape2D
private:
    double length; // Private member variable to store the length of the rectangle
    double width; // Private member variable to store the width of the rectangle

public:
    // Constructor for Rectangle class
    Rectangle(double len, double wid) : length(len), width(wid) {}

    // Override the virtual member function to calculate the area
    double calculateArea() const override {
        return length * width; // Calculate the area of the rectangle using its length and width
    }

    // Override the virtual member function to calculate the perimeter
    double calculatePerimeter() const override {
        return 2 * (length + width); // perimeter of a rectangle
    }
};