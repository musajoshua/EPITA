#pragma once
#include "Shape2D.h"
class Parallelogram : public Shape2D { // Derived class inheriting from Shape2D
private:
    double base; // Private member variable to store the base of the Parallelogram
    double side; // Private member variable to store the side of the Parallelogram
    double heigth; // Private member variable to store the height of the Parallelogram

public:
    // Constructor for Parallelogram class
    Parallelogram(double bas, double sid, double hei) : base(bas), side(sid), heigth(hei) {}

    // Override the virtual member function to calculate the area
    double calculateArea() const override {
        return base*heigth; // area of a parallelogram 
    }

    // Override the virtual member function to calculate the perimeter
    double calculatePerimeter() const override {
        return 2*(side + base); // perimeter of a parallelogram
    }
};