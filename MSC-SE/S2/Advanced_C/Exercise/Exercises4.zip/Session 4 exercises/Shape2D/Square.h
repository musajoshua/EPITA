#pragma once
#include "Shape2D.h"
class Square : public Shape2D { // Derived class named Rectangle inheriting from Shape2D
private:
    double sidelength; // Private member variable to store the side length of the square

public:
    // Constructor for Rectangle class
    Square(double sidelen) : sidelength(sidelen) {}

    // Override the virtual member function to calculate the area
    double calculateArea() const override {
        return sidelength * sidelength; // Carea of the square
    }

    // Override the virtual member function to calculate the perimeter
    double calculatePerimeter() const override {
        return 4 * sidelength; // perimeter of a rectangle
    }
};