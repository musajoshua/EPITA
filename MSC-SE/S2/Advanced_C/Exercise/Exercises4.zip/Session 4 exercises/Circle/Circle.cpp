// division.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream> // Include necessary header for input/output stream

#include <cmath> // Include necessary header for mathematical functions

const double PI = 3.14159; // Define the value of PI as a constant

class Circle { // Define a class named Circle
private:
    double radius; // Private member to store the radius

public:
    // Constructor to initialize the Circle object with a radius
    Circle(double rad) : radius(rad) {}

    // Member function to calculate the area of the circle
    double calculateArea() {
        return PI * pow(radius, 2); // Formula to calculate the area of a circle
    }

    // Member function to calculate the circumference of the circle
    double calculateCircumference() {
        return 2 * PI * radius; // Formula to calculate the circumference of a circle
    }
};

int main() {
    // Create a circle object
    double radius;
    std::cout << "Input the radius of the circle: ";
    std::cin >> radius; // Input the radius from the user
    Circle circle(radius); // Create a Circle object with the given radius

    // Calculate and display the area of the circle
    double area = circle.calculateArea(); // Calculate the area using the Circle object
    std::cout << "Area: " << area << std::endl; // Output the calculated area

    // Calculate and display the circumference of the circle
    double circumference = circle.calculateCircumference(); // Calculate the circumference using the Circle object
    std::cout << "Circumference: " << circumference << std::endl; // Output the calculated circumference

    return 0; // Return 0 to indicate successful completion
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
