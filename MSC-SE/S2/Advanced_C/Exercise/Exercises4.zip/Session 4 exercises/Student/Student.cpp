// Student.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
using namespace std;

class Student {

public:
	char* name;
	int mark1; int mark2;
	Student(char* na, int ma1, int ma2) {
		name = na; mark1 = ma1; mark2 = ma2;
	}
	void disp() {
		cout << "Student:" << name << " \n media:" << calc_media() << "\n";
	}
private:
	int calc_media() { return (mark1 + mark2) / 2; }

};

int main() {

	char nam[50]; int m1, m2;

	cout << "Enter name:";
	cin >> nam;
	cout << "Enter marks of two subjects:";
	cin >> m1;
	cin >> m2;
	Student student1(nam, m1, m2);
	student1.disp();

	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
