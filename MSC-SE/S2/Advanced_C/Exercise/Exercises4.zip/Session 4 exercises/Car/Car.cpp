// Car.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>

using namespace std;

class Car {

private:

	string brand;
	string model;
	int year;

public:

	// Constructor
	Car(string b, string m, int y) : brand(b), model(m), year(y) {}

	// Setter method
	void setDetails(string b, string m, int y) {

		brand = b;
		model = m;
		year = y;

	}
	// Display method
	void displayDetails() {
		cout << "Brand: " << brand << ", Model : " << model << ", Year : " << year << endl;
	}
};

int main() {

	Car myCar("Toyota", "Camry", 2020);
	myCar.displayDetails();

	// Update details
	myCar.setDetails("Honda", "Civic", 2022);
	myCar.displayDetails();

	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
