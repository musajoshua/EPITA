// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main()
{
    vector<int> MyVector = { 8, 4, 5, 9 };
    int Vsize = MyVector.size();
    // Add two more integers to vector
    MyVector.push_back(7);
    MyVector.push_back(11);
    Vsize = MyVector.size();
    // Overwrite element at position 2
    MyVector[2] = -1;
    MyVector.at(3) = 88;    
    for (int n : MyVector)
        cout << n << ' ';
    MyVector.clear();
    Vsize = MyVector.size();
    cout << '\n';
    cout << '\n';

    // Create a vector called cars that will store strings
    vector<std::string> cars = { "Volvo", "BMW", "Ford", "Mazda" };
    cars.push_back("Tesla");
    cars.push_back("VW");
    cars.push_back("Mitsubishi");
    cars.push_back("Mini");
    // Print vector elements
    for (string car : cars) {
        cout << car << "\n";
    }
    cout << '\n';
    // Create an empty vector of type <string>.
    vector <string> ingredients;
    // Append "eggs," "milk," "sugar," "chocolate," and "flour" elements to the vector.
    // Print it.
    ingredients.push_back("eggs");
    ingredients.push_back("milk");
    ingredients.push_back("sugar");
    ingredients.push_back("chocolate");
    ingredients.push_back("flour");

    for (string ingredient : ingredients) {
        cout << ingredient << "\n";
    }
    cout << '\n';
    //    Remove the last element from the vector.Print it.
    ingredients.pop_back();
    for (string ingredient : ingredients) {
        cout << ingredient << "\n";
    }
    cout << '\n';
        //    Append the item, "coffee" to the vector.Print it.
    ingredients.push_back("coffee");
    ingredients.push_back("tea");
    ingredients.push_back("oil");
    ingredients.push_back("salt");
    ingredients.push_back("vinegar");
    ingredients.push_back("wheat");
    for (string ingredient : ingredients) {
        cout << ingredient << "\n";
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
