// vector2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
using namespace std;
#include <iostream>
#include <vector>
int main()
{
    vector <string> ingredients; // Create an empty vector of type <string>
    char* p1 = NULL;
    //*p1 = 'a';
    int* p2 = NULL;
    {
        int n;
        p2 = &n;
    }
    int MyArr[10] = { -2, 2, -4, 4, -6, 6, -8, 10, 23, -33 };
    *p2 = MyArr[5];
    float y;
    for (int i = 0; i <= 10; i++)
    {
        y = 1 / MyArr[i];
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
