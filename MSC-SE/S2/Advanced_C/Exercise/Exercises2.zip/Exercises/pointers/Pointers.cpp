// pointers.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include <algorithm>
using namespace std;

#include <vector>
#include <list>

// overloading functions
#include <iostream>
using namespace std;
void swap_elements(int* a, int* b)
{
    int t = *a; // Temporary variable to store the value at pointer a
    *a = *b; // Assigning the value at pointer b to pointer a
    *b = t; // Assigning the value in the temporary variable to pointer b
}
void PlayWithPointers() {
    int i = 7, j;
    int* p = &i;    // creates ptr p, Stores address of i in p
    int** pp = &p;  // creates dble ptr pp, stores address of p in pp
    j = ++(**pp);   // FIRST increment(**pp) => i = 8
                    // THEN assign value **pp to j => j = 8
    i++;            // Increment i by one => i = 9
    j = (**pp)++;   // FIRST assign value **pp to j => j = 9
                    // THEN increment(**pp) => i = 10

}

int find_largest(int nums[], int n) {
    int Max = 0;
    for (int i = 0; i < n; i++)
    {
        if (nums[i] > Max) 
            Max = nums[i];
    }
    return Max;
}
int main() {

    printf("hello");

//    PlayWithPointers();
    //array initialisation
    int demo[5] = { 5, 4, 3, 2, 1 };

    int len = sizeof(demo) / sizeof(demo[0]);

    cout << "Before sorting array : ";
    for (int i = 0; i < len; i++)
    {
        cout << " " << demo[i];
    }

    std::sort(demo, demo + len);//Sorting demo array

    cout << "\n\nAfter sorting array : ";
    for (int i = 0; i < len; i++)
    {
        cout << " " << demo[i];
    }


    // find largest element in an array
    int nums[10] = { 1992, 222, 3, 4, -333, 0, -22, 7, 8, 555 };
    int n = sizeof(nums) / sizeof(nums[0]); // get nb of elts in array

    cout << "array: "; // Output message indicating the original array is being displayed
    for (int i = 0; i < n; i++)
        cout << nums[i] << " "; // Output each element of the array

    int maxnb = find_largest(nums, n); // Calling function to find the second largest element in the array
    
    char buffer[33];
    _itoa_s(maxnb, buffer, 10);
    cout << "\n Max value of array is : " << buffer; 

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
