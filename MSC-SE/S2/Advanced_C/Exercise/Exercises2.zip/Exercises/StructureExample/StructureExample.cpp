// StructureExample.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

/**
 * C program to illustrate structures.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


 // Student type definition
struct student
{
    char name[40];  // Student name
    int  age;       // Student age
    int mobile;     // Student mobile number
};


int main()
{
    struct student student1;    // Simple structure variable
    struct student* student2;   // Pointer to student


    // Initialize pointer to student through dynamic memory allocation
    student2 = (struct student*)malloc(sizeof(struct student));

    // Input data in structure members using dot operator
    printf("Enter student name: ");
    fgets(student1.name, 40, stdin);

    printf("Enter student age: ");
    scanf_s("%d", &student1.age);

    printf("Enter student mobile: ");
    scanf_s("%d", &student1.mobile);

    // Eat new line from input buffer
    getchar();

    printf("\n print Student using simple structure variable:\n");
    printf("Student name: %s\n", student1.name);
    printf("Student age: %d\n", student1.age);
    printf("Student mobile: %d\n\n", student1.mobile);



    // Input data in pointer to structure type using arrow operator
    printf("Enter student name: ");
    fgets(student2->name, 40, stdin);

    printf("Enter student age: ");
    scanf_s("%d", &student2->age);

    printf("Enter student mobile: ");
    scanf_s("%d", &student2->mobile);

    printf("\n Print Student using pointer to structure variable:\n");
    printf("Student name: %s\n", student2->name);
    printf("Student age: %d\n", student2->age);
    printf("Student mobile: %d\n", student2->mobile);


    // Clear memory that was alloacted dynamically
    free(student2);

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
