// Arrays.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

/**
 * C program to find the average of all elements of an array
 */

#include <stdio.h>
#define ARRAY_SIZE 10

int main()
{
    float arr[ARRAY_SIZE];
    
    int i, n = ARRAY_SIZE;
    
    float avg, sum = 0;
    
    /* Input elements in array */
    printf("Enter %d elements in the array: ", n);
    for (i = 0; i < n; i++)
    {
        scanf_s("%f", &arr[i]);
    }

    /*
     * Add each array element to sum
     */
    for (i = 0; i < n; i++)
    {
        sum = sum + arr[i];
    }
    avg = sum / ARRAY_SIZE;

    printf("The average of all values entered is : %f", avg);

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
