// BufferOverwrite.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// this program generates an exception at the last iteration line 18 as it tries to 
// write at location numbers[10], which does not exist. 
// Declaring an array of ten elements (int numbers[10];) means that 
// the 10 elements of the array are numbers[0] to numbers[9]
// if you build this program and execute you will see an exception occur
// to fix that bug one just has to replace i <= 10 by i < 10 at line 16

#include <iostream>

int main()
{
    struct Point2D {
        float x;
        float y;
    };

    Point2D P;

    P.x = 2.0;
    P.y = -1.5;

    Point2D* Ptr;

    Ptr = &P;
    Ptr->x = 0.0;
    Ptr->y = -3.0;
    
    int a = 7, b, c,d, e;
    int* p; // Un-initialized Pointer
    p = &a; // Stores address of a in p
    b = *p + 1; // value of b�?

    int** pp = &p;
    
    c = ++(**pp);// value of c?
    
    d = (**pp)++;// value of d?

    
    e = ++(**pp);// value of e?

    return 0;


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
