// MaxNumber.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

/**
 * C program to find maximum between three numbers using conditional operator
 */

#include <stdio.h>

int main()
{
    int num1, num2, num3, max, max2;

    /*
     * Input three numbers from user
     */
    printf("Enter three numbers: ");
    scanf_s("%d%d%d", &num1, &num2, &num3);

    /*
     * If num1 > num2 and num1 > num3 then
     *     assign num1 to max
     * else if num2 > num3 then
     *     assign num2 to max
     * else
     *     assign num3 to max
     */
    if ((num1 > num2) && (num1 > num3))
    {
        max = num1;
    }
    else if (num2 > num3)
    {
        max = num2;
    }
    else
        max = num3;

    printf("\nMaximum between %d, %d and %d = %d", num1, num2, num3, max);

    // short-cut in C :
    max2 = (num1 > num2 && num1 > num3) ? num1 :
        (num2 > num3) ? num2 : num3;

    printf("\nMaximum2 between %d, %d and %d = %d", num1, num2, num3, max2);

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
