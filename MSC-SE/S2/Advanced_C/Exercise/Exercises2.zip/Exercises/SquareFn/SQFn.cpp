float SquareFn(float x)
{
	float y = x*x;
	return y;
}
