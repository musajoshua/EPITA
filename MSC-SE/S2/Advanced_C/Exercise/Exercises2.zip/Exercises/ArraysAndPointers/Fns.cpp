int Sortarr(float *arr, int N)
{
    int i, j;
    float c;
    for (i = 0; i < N - 1; i++)
    {
        for (j = i + 1; j < N; j++)
        {
            // if not ordered properly swap elements
            if (arr[i] > arr[j]) 
            {
                c = arr[i];
                arr[i] = arr[j];
                arr[j] = c;
            }
        }

    }
    return 0;
}
 