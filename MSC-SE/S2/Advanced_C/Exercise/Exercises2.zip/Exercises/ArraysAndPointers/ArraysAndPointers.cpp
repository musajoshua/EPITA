// ArraysAndPointers.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

    /**
     * C program to input and print array elements using pointers
     */

using namespace std;
#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE 11

int Sortarr(float* arr, int N);

int compare(const void* a, const void* b) {
    return (*(int*)a - *(int*)b);
}

int main()
{
    float arr[ARRAY_SIZE];

    int i, n = ARRAY_SIZE;

    float avg, median, sum = 0;

    /* Input elements in array */
    printf("Enter %d elements in the array: ", n);
    for (i = 0; i < n; i++)
    {
        scanf_s("%f", &arr[i]);
    }
    /*
     * Add each array element to sum
     */
    for (i = 0; i < n; i++)
    {
        sum = sum + arr[i];
    }
    avg = sum / ARRAY_SIZE;

    printf("The average of all values entered is : %f", avg);

    // calculate median
    // Sort the array using std::sort()
    int nb = sizeof(arr) / sizeof(arr[0]);// get the number of elts if it was unknown
    qsort(arr, nb, sizeof(arr[0]), compare);
    // alternate "manual" sorting function: see code
    //Sortarr(arr, nb);

    // median is the 6th element in case of array of 11 values
    int medianrank = (nb + 1) / 2;
    median = arr[medianrank-1];
    printf("The median value of all values entered is : %f", median);


    return 0;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
