import time

def isPrime(n):
    for i in range(2,int(n**0.5)+1):
        if n%i==0:
            return False

    return True

n = 0
start = time.time()
print("start time: ", start)
while ( n < 1000000):
    if isPrime(n):
        print(n)
    n+=1
end = time.time()
print("stop time: ", end)
print("elapsed time :", end - start)