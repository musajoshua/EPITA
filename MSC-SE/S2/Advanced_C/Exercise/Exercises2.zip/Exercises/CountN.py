import time
n = 0
start = time.time()
print("start time: ", start)
while ( n < 100000000):
    n+=1
print(n)
end = time.time()
print("stop time: ", end)
print("elapsed time :", end - start)