// ClosestToN.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

// Write a C++ program to check which number is closest to the value 1000 
// among two given integers.Return 0 if the two numbers are equal.

// Function to determine the number closer to 1000 among two integers
int test(int x, int y)
{
    const int n = 1000; // Constant integer n is set to 100

    // Calculate the absolute difference between x and n, and between y and n
    int val = abs(x - n);
    int val2 = abs(y - n);

    // Check if the absolute differences are equal or not
    // If equal, return 0; otherwise, return the number closest to 100
    return val == val2 ? 0 : (val < val2 ? x : y);
}

// Main function
int main()
{
    cout << test(780, 1295) << endl;   // Output the result of test function with values 78 and 95
    cout << test(850, 1095) << endl;   // Output the result of test function with values 95 and 95
    cout << test(899, 1070) << endl;   // Output the result of test function with values 99 and 70
    return 0;    // Return 0 to indicate successful execution of the program
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
