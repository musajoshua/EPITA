// SortInWaveForm.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include<iostream> // Header file for input/output stream
#include<algorithm> // Header file for using algorithms like sort
using namespace std; // Using the standard namespace

void swap_elements(int* a, int* b)
{
    int t = *a; // Temporary variable to store the value at pointer a
    *a = *b; // Assigning the value at pointer b to pointer a
    *b = t; // Assigning the value in the temporary variable to pointer b
}

void array_wave(int nums[], int n)
{
    sort(nums, nums + n); // Sorting the array in ascending order using the sort function

    // Loop to create the wave pattern in the array
    for (int i = 0; i < n - 1; i += 2)
        swap_elements(&nums[i], &nums[i + 1]); // Swapping adjacent elements to create the wave pattern
}

int main()
{
    int nums[] = { 4, 5, 9, 12, 9, 22, 45, 7 }; // Declaration and initialization of an integer array
    int n = sizeof(nums) / sizeof(nums[0]); // Calculating the number of elements in the array
    cout << "Original array: ";
    for (int i = 0; i < n; i++)
        cout << nums[i] << " "; // Outputting each element of the array
    array_wave(nums, n); // Calling the function to create a wave pattern in the array
    cout << "\nWave form of the said array: ";
    for (int i = 0; i < n; i++)
        cout << nums[i] << " "; // Outputting each element of the modified array in a wave pattern
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
