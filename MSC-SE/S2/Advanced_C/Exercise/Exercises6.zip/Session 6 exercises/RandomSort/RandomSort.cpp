// RandomSort.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
using namespace std;

#include <iostream>
#include <stdlib.h> // rand(), srand()
#include<algorithm>
// this program generates a randomly ordered list of the first 17 integer numbers 1 to 17
// the goal is to provide a random order of passage for examination of 17 projects:
// a) generate a list of 17 random numbers using rand() function
// b) sort the result from lowest to greatest
// c) at the same time store the index of the lowest as first in the output, etc...
// 
#define NbProjects 12

int Rank[NbProjects], SortedRank[NbProjects], FinalOrder[NbProjects];

int main() {
    // Print n random numbers.
    for (int i = 0; i < NbProjects; i++)
    {
        Rank[i] = rand();
        SortedRank[i] = Rank[i];
    }
    std::sort(SortedRank, SortedRank + NbProjects);//Sorting array
    for (int i = 0; i < NbProjects; i++)
    {
        for (int j = 0; j < NbProjects; j++)
        {
            if (Rank[j] == SortedRank[i])
            {
                FinalOrder[i] = j + 1;// this will create the list of project numbers randomized from 1 to 17
            }
        }
        cout << " \n " << FinalOrder[i];
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
