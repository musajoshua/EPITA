// Algorithms.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream> // Include input/output stream library
#include <cmath> // Include math functions
#include < ctime > 
#include <chrono>
#include <vector>
using namespace std; // Using standard namespace

#define ABSENT_VALUE -999.25;

const int nbloops = 1000000;
double func()
{
	clock_t begin = clock();

	//Code to measure here
	double a = 2.45, b = 5.111, pi = 3.14;

	for (int i = 0; i < nbloops; i++) { // loop will try to write on 11th element
		float x, y;
		double c = (pow(a, 2) + pow(b, 2)) / pi;
		x = sqrt(c);
		y = pow(x, 2);//
	}
	clock_t end = clock();
	double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;

	return elapsed_secs;
}
double optfunc()
{
	clock_t begin = clock();

	//Code to measure here
	double a = 2.45;
	double b = 5.111;
	double pi = 3.14;
	double c = (pow(a, 2) + pow(b, 2)) / pi;

	for (int i = 0; i < nbloops; i++) { // loop will try to write on 11th element
		float x, y;
		x = sqrt(c);
		y = x*x;//
	}
	clock_t end = clock();
	double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;

	return elapsed_secs;

}

int main() 
{
	double elapsedfunc = func();
	std::cout << " \n duration func : " << elapsedfunc << "s";

	double elapsedoptfunc = optfunc();
	std::cout << " \n duration optfunc : " << elapsedoptfunc << "s";

	double gain = elapsedfunc / elapsedoptfunc;
	std::cout << " \n gain by a factor of : " << gain;

	return 0; // Return 0 to indicate successful completion
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
