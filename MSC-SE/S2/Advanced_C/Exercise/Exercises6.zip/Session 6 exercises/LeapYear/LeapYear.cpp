// LeapYear.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// C++ program to check if a given
// year is a leap year or not
#include <iostream>
using namespace std;

// Function to check leap year
bool checkYear(int year)
{
    if (year % 400 == 0) {
        return true;
    }

    // not a leap year if divisible by 100
    // but not divisible by 400
    else if (year % 100 == 0) {
        return false;
    }

    // leap year if not divisible by 100
    // but divisible by 4
    else if (year % 4 == 0) {
        return true;
    }

    // all other years are not leap years
    else {
        return false;
    }
}

// Driver code
int main()
{
    int year = 2000;

    checkYear(year) ? cout << "Leap Year"
        : cout << "Not a Leap Year";

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
