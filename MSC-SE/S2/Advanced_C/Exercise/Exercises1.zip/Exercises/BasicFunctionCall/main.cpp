// BasciFunctionCall.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>




int main()
{
    struct Point2D {
        float x;
        float y;
    };

    Point2D Pxy;
    
    Pxy.x = 2.0;
    Pxy.y = -1.5;

    Point2D* Ptr;

    Ptr = &Pxy;
    float x1 = Ptr->x;
    float y1 = Ptr->y;


    return 0;
}

