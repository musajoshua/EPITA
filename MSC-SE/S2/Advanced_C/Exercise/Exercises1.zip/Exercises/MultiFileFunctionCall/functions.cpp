
//#include "functions.h"

float SquareFn( float x)
{
    float y;
    y = x * x;
    return y;
}


