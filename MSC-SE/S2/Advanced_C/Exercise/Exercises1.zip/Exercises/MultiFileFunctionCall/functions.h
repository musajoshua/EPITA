// "signature" or "prototype" of the SquareFn  function
float SquareFn(float x);
