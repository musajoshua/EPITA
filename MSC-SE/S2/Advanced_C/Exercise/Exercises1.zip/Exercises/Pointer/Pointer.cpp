// Pointer.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

int main()
{
	int* ptra;; // declares a pointer ptra to an integer
	int a; // declares an integer a
	a = 5; // the value of a is now 5
	ptra = &a; // assigns to ptra the value of the address of a
	int b = *ptra; // integer b is assigned as value the content 
	               // of the memory location pointed by ptra, which is 5
	return 0;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
